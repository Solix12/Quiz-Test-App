package com.salikh.nurtest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.util.ArrayList;

public class MistakesActivity extends AppCompatActivity {

    private TextView  mistacke;
    private ArrayList<String > list = new ArrayList<>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mistakes);
        
        
        loadViews();
        setDataToView();
        listLoad();
        
    }

    private void listLoad() {
        Bundle bundle = getIntent().getExtras();
        list.addAll(bundle.getStringArrayList("mistakes"));
    }

    private void setDataToView() {
        Log.d("1", "setDataToView: "+list.toString());
        mistacke.setText(list.toString());
    }

    private void loadViews() {
        mistacke = findViewById(R.id.mistakes_text);
    }



}